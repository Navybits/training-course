export default {
  increment: function() {
    return { type: "INCREMENT" };
  },
  decrement: function() {
    return { type: "DECREMENT" };
  }
};
